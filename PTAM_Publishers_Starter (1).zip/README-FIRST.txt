PTAM PUBLISHERS — STARTER WEBSITE

WHAT IS INCLUDED
- Responsive homepage design
- Email and WhatsApp submission links
- Search UI (currently searches the sample preview cards only)
- Privacy and publishing-policy starter pages
- robots.txt and starter sitemap.xml
- /admin/ folder with a Decap CMS configuration starter

IMPORTANT LIMITATION
This is the website starter, not a fully activated publishing dashboard yet. The admin CMS needs a real GitHub repository and OAuth authentication configuration. Netlify's old Identity/Git Gateway setup is deprecated for new projects, so do not assume the placeholder auth configuration will work as-is.

RECOMMENDED NEXT STEPS
1. Create a GitHub account if you do not have one.
2. Create a NEW repository for this site.
3. Upload all files/folders in this package to the repository's main branch.
4. In Netlify, choose Add new site -> Import an existing project, connect GitHub, and select the repository.
5. In the deployment settings, set Publish directory to "."; no build command is needed for the static starter.
6. Connect your domain only after the site is deployed and test the Netlify preview URL first.
7. The CMS config at admin/config.yml must be updated with your actual repository and a supported authentication backend before /admin/ can securely publish content.

HOW ARTICLE PAGES WILL WORK
The CMS is configured to store article Markdown files in content/articles and PDFs/images in uploads. A static site generator/template step must be added to render each Markdown article into its own public page and to generate a complete sitemap. This first starter package does not yet include that renderer, so do not treat the CMS as ready for production until that step and authentication are completed.

EMAIL AND WHATSAPP
Email submissions open ptam.publishers@gmail.com.
WhatsApp submissions open +254748197045.
